Ring For WebAssembly using Qt
=============================

Requirements:

* Qt 5.15.0 
* Emscripten 1.39.7
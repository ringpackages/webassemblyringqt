/* Copyright (c) 2013-2021 Mahmoud Fayed <msfclipper@yahoo.com> */
#include "ring.h"

int main ( int argc, char *argv[] )
{
	ring_state_main(argc,argv);
}

/* Copyright (c) 2013-2024 Mahmoud Fayed <msfclipper@yahoo.com> */

#include "ring.h"

int main ( void )
{
	printf("Hello, World!\n");
	return RING_EXIT_OK ;
}

/* Custom Configuration File (Could be modified when embedding Ring in other projects) */

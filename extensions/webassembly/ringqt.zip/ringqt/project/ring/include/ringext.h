#ifndef ringext_h
#define ringext_h
/* Constants */
#define RING_VM_MYSQL
#define RING_VM_ODBC
#define RING_VM_OPENSSL
#define RING_VM_CURL
#endif

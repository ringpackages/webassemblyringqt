#ifndef RING_QT
#define RING_QT

extern "C" {
void ring_qt_start(RingState *pRingState);
}

#endif
